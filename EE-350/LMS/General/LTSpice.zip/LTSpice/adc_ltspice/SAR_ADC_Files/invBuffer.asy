Version 4
SymbolType BLOCK
LINE Normal -48 0 -32 0
LINE Normal 64 0 48 0
LINE Normal -32 33 -32 -32
LINE Normal 48 0 -32 33
LINE Normal -32 -32 48 0
LINE Normal 0 20 0 32
LINE Normal 0 -19 0 -32
TEXT -10 -16 Left 1 +
TEXT -8 16 Left 2 -
TEXT -24 -1 Left 1 buffer
PIN -48 0 NONE 8
PINATTR PinName in
PINATTR SpiceOrder 1
PIN 64 0 NONE 8
PINATTR PinName out
PINATTR SpiceOrder 2
PIN 0 -32 NONE 8
PINATTR PinName vhigh
PINATTR SpiceOrder 3
PIN 0 32 NONE 8
PINATTR PinName vlow
PINATTR SpiceOrder 4
