Version 4
SymbolType BLOCK
LINE Normal 0 32 0 -32
LINE Normal 64 0 0 32
LINE Normal 0 -32 64 0
LINE Normal 32 -32 32 -16
LINE Normal 32 32 32 16
LINE Normal -16 0 0 0
LINE Normal 96 0 80 0
CIRCLE Normal 80 8 64 -8
TEXT 8 0 Left 0 20/10
PIN 32 -32 NONE 8
PINATTR PinName VHIGH
PINATTR SpiceOrder 1
PIN 32 32 NONE 3
PINATTR PinName VLOW
PINATTR SpiceOrder 2
PIN -16 0 NONE 8
PINATTR PinName Vin
PINATTR SpiceOrder 3
PIN 96 0 NONE 8
PINATTR PinName Vout
PINATTR SpiceOrder 4
