Version 4
SymbolType BLOCK
LINE Normal -96 -48 -48 -16
LINE Normal -96 16 -48 -16
LINE Normal -7 4 0 0
LINE Normal 9 -11 0 0
LINE Normal 112 -32 128 -32
LINE Normal 128 0 112 0
LINE Normal 128 32 112 32
LINE Normal -112 -16 -96 -16
LINE Normal -64 64 -64 48
LINE Normal -64 -96 -64 -80
LINE Normal 128 -64 112 -64
RECTANGLE Normal 112 48 -96 -80
CIRCLE Normal 16 16 -16 -16
TEXT -80 -16 Top 0 In
TEXT -36 -35 Left 2 Clocks
TEXT 110 -32 Right 1 Clk_SH
TEXT 110 0 Right 1 SAR_SR
TEXT 110 32 Right 1 Clk_Door
TEXT -64 46 Bottom 1 gnd
TEXT -64 -78 Top 1 vdd
TEXT 110 -64 Right 1 2MHz_Out
TEXT -80 -16 Bottom 0 4MHz
PIN 128 -32 NONE 8
PINATTR PinName Clk_SH
PINATTR SpiceOrder 1
PIN 128 0 NONE 8
PINATTR PinName SAR_SR
PINATTR SpiceOrder 2
PIN 128 32 NONE 8
PINATTR PinName clk_door
PINATTR SpiceOrder 3
PIN -112 -16 NONE 8
PINATTR PinName clk_in
PINATTR SpiceOrder 4
PIN -64 -96 NONE 8
PINATTR PinName VHIGH
PINATTR SpiceOrder 5
PIN -64 64 NONE 8
PINATTR PinName VLOW
PINATTR SpiceOrder 6
PIN 128 -64 NONE 8
PINATTR PinName clk_2MHz
PINATTR SpiceOrder 7
