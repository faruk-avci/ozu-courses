Version 4
SymbolType BLOCK
LINE Normal -80 -128 -96 -128
LINE Normal -80 -96 -96 -96
LINE Normal -96 -64 -80 -64
LINE Normal -80 -32 -96 -32
LINE Normal -96 0 -80 0
LINE Normal -96 32 -80 32
LINE Normal -96 64 -80 64
LINE Normal -96 96 -80 96
LINE Normal 0 128 0 144
LINE Normal 48 -16 64 -16
RECTANGLE Normal 48 128 -80 -160
TEXT -76 94 Left 2 in0
TEXT -76 62 Left 2 in1
TEXT -76 31 Left 2 in2
TEXT -75 -1 Left 2 in3
TEXT -75 -34 Left 2 in4
TEXT -75 -66 Left 2 in5
TEXT -75 -97 Left 2 in6
TEXT -75 -130 Left 2 in7
TEXT -26 113 Left 2 VLOW
TEXT -14 -18 Left 2 Vout
TEXT -24 -141 Left 3 R2R
TEXT -24 -111 Left 3 DAC
PIN 0 144 NONE 8
PINATTR PinName VLOW
PINATTR SpiceOrder 1
PIN 64 -16 NONE 8
PINATTR PinName vout
PINATTR SpiceOrder 2
PIN -96 96 NONE 8
PINATTR PinName in0
PINATTR SpiceOrder 3
PIN -96 64 NONE 8
PINATTR PinName in1
PINATTR SpiceOrder 4
PIN -96 32 NONE 8
PINATTR PinName in2
PINATTR SpiceOrder 5
PIN -96 0 NONE 8
PINATTR PinName in3
PINATTR SpiceOrder 6
PIN -96 -32 NONE 8
PINATTR PinName in4
PINATTR SpiceOrder 7
PIN -96 -64 NONE 8
PINATTR PinName in5
PINATTR SpiceOrder 8
PIN -96 -96 NONE 8
PINATTR PinName in6
PINATTR SpiceOrder 9
PIN -96 -128 NONE 8
PINATTR PinName in7
PINATTR SpiceOrder 10
