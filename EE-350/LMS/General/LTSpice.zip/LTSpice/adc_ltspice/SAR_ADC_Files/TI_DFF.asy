Version 4
SymbolType BLOCK
LINE Normal -48 16 -64 0
LINE Normal -64 32 -48 16
LINE Normal -32 -96 -32 -64
LINE Normal -32 96 -32 64
LINE Normal -96 -48 -64 -48
LINE Normal 96 -48 64 -48
LINE Normal -96 16 -64 16
LINE Normal 96 32 64 32
LINE Normal 16 96 16 64
LINE Normal 16 -96 16 -64
RECTANGLE Normal 64 64 -64 -64
TEXT -59 -48 Left 1 D
TEXT 39 -48 Left 1 Q
TEXT -36 -48 Left 1 S
TEXT -38 49 Left 1 R
TEXT 39 29 Left 1 Q_
TEXT -41 16 Left 1 Clk
TEXT -2 49 Left 1 GND
TEXT 0 -48 Left 1 Vdd
PIN -32 -96 NONE 8
PINATTR PinName Set_not
PINATTR SpiceOrder 1
PIN -96 16 NONE 8
PINATTR PinName Clk
PINATTR SpiceOrder 2
PIN -96 -48 NONE 8
PINATTR PinName Data
PINATTR SpiceOrder 3
PIN -32 96 NONE 8
PINATTR PinName Reset_not
PINATTR SpiceOrder 4
PIN 96 -48 NONE 8
PINATTR PinName Q
PINATTR SpiceOrder 5
PIN 96 32 NONE 8
PINATTR PinName Q_not
PINATTR SpiceOrder 6
PIN 16 96 NONE 8
PINATTR PinName VLOW
PINATTR SpiceOrder 7
PIN 16 -96 NONE 8
PINATTR PinName VHIGH
PINATTR SpiceOrder 8
