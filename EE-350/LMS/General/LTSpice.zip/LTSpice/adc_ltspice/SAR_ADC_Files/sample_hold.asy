Version 4
SymbolType BLOCK
LINE Normal -144 0 -128 0
LINE Normal 144 0 128 0
LINE Normal 64 64 64 48
LINE Normal -64 48 -64 64
LINE Normal -64 -80 -64 -64
RECTANGLE Normal -128 -64 128 48
TEXT -126 0 Left 2 Vin
TEXT 73 -1 Left 2 Vout
TEXT -110 -28 Left 3 Sample / Hold
TEXT -96 -57 Left 2 vhigh
TEXT 36 38 Left 2 vlow
TEXT -80 38 Left 2 clk
PIN -144 0 NONE 8
PINATTR PinName Sample_In
PINATTR SpiceOrder 1
PIN -64 -80 NONE 8
PINATTR PinName VHIGH
PINATTR SpiceOrder 2
PIN 64 64 NONE 8
PINATTR PinName VLOW
PINATTR SpiceOrder 3
PIN 144 0 NONE 8
PINATTR PinName Vout
PINATTR SpiceOrder 4
PIN -64 64 NONE 8
PINATTR PinName clk
PINATTR SpiceOrder 5
