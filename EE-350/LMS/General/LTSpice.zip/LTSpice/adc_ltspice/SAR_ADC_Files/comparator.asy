Version 4
SymbolType BLOCK
LINE Normal -64 64 -64 -64
LINE Normal -80 -32 -64 -32
LINE Normal -64 32 -80 32
LINE Normal 80 0 96 0
LINE Normal 80 0 -64 -64
LINE Normal -64 64 80 0
LINE Normal -16 -43 -16 -64
LINE Normal -16 43 -16 64
TEXT -58 -33 Left 2 +
TEXT -54 30 Left 3 -
TEXT -36 -2 Left 2 comp
PIN -80 -32 NONE 8
PINATTR PinName vp
PINATTR SpiceOrder 1
PIN -80 32 NONE 8
PINATTR PinName vm
PINATTR SpiceOrder 2
PIN 96 0 NONE 8
PINATTR PinName Vout
PINATTR SpiceOrder 3
PIN -16 -64 NONE 8
PINATTR PinName vhigh
PINATTR SpiceOrder 4
PIN -16 64 NONE 8
PINATTR PinName vlow
PINATTR SpiceOrder 5
