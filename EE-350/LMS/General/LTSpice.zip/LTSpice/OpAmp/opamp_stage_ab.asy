Version 4
SymbolType BLOCK
LINE Normal -96 37 -96 -79
LINE Normal 32 -32 -96 37
LINE Normal -96 -80 32 -32
LINE Normal -32 -55 -32 -80
LINE Normal -32 3 -32 32
WINDOW 0 -3 -95 Bottom 2
PIN -96 -48 RIGHT 8
PINATTR PinName In+
PINATTR SpiceOrder 1
PIN -96 0 RIGHT 8
PINATTR PinName In-
PINATTR SpiceOrder 2
PIN 32 -32 RIGHT 8
PINATTR PinName out
PINATTR SpiceOrder 3
PIN -32 -80 RIGHT 8
PINATTR PinName VDD
PINATTR SpiceOrder 4
PIN -32 32 RIGHT 8
PINATTR PinName VSS
PINATTR SpiceOrder 5
