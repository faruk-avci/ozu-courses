Version 4
SymbolType BLOCK
LINE Normal -48 48 -48 -48
LINE Normal 31 0 -48 48
LINE Normal -48 -48 31 0
LINE Normal 48 0 31 0
LINE Normal -64 -32 -48 -32
LINE Normal -64 32 -48 32
LINE Normal -16 -48 -16 -29
LINE Normal -16 28 -16 48
TEXT -48 -32 Left 0 In+
TEXT -48 32 Left 0 In-
TEXT 25 12 Left 0 OUT
TEXT -11 -38 Left 0 VDD
TEXT -9 39 Left 0 VSS
PIN -64 -32 NONE 8
PINATTR PinName IN+
PINATTR SpiceOrder 1
PIN -64 32 NONE 8
PINATTR PinName IN-
PINATTR SpiceOrder 2
PIN 48 0 NONE 8
PINATTR PinName OUT
PINATTR SpiceOrder 3
PIN -16 -48 NONE 8
PINATTR PinName VDD
PINATTR SpiceOrder 4
PIN -16 48 NONE 8
PINATTR PinName VSS
PINATTR SpiceOrder 5
