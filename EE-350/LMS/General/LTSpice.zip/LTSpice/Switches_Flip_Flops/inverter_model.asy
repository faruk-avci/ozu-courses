Version 4
SymbolType BLOCK
LINE Normal 0 16 0 -48
LINE Normal 64 -16 0 16
LINE Normal 0 -48 64 -16
LINE Normal 0 -16 0 -48
LINE Normal -16 -16 0 -16
LINE Normal 0 -16 -16 -16
LINE Normal 0 0 0 -16
LINE Normal 0 16 0 0
LINE Normal 64 -16 0 16
LINE Normal 80 -16 64 -16
LINE Normal 32 -48 32 -32
LINE Normal 32 -32 32 -48
LINE Normal 64 -16 32 -32
LINE Normal 32 0 64 -16
LINE Normal 32 16 32 0
CIRCLE Normal 73 -12 64 -20
PIN -16 -16 NONE 8
PINATTR PinName inp
PINATTR SpiceOrder 1
PIN 80 -16 NONE 8
PINATTR PinName out
PINATTR SpiceOrder 2
PIN 32 -48 NONE 8
PINATTR PinName VDD
PINATTR SpiceOrder 3
PIN 32 16 NONE 8
PINATTR PinName VSS
PINATTR SpiceOrder 4
