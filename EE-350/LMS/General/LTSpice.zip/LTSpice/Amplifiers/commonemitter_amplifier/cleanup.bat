del /s *.net
del /s *.raw
del /s *.log
del /s *.fft
del /s PIsection.asy
